package com.example.abid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
